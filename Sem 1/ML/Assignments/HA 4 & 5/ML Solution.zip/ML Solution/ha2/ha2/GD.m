function [theta, arrCost] = GD(X, theta, y, alpha, numIters)
% Gradient Descent Method

m = length(y);
arrCost = zeros(numIters, 1);
thetaLen = length(theta);
tempVal = theta;
for iter=1:numIters
     %PLACEHOLDER#start: write your codes to update theta, i.e., the parameters to estimate. 
            tempVal=rand(3,1);
            theta = theta - (alpha/m)*tempVal;    
    %PLACEHOLDER#end
     
    %PLACEHOLDER#start
        %calculate the current cost with the present theta; 
        arrCost(iter) = 0; 
    %PLACEHOLDER#end   
    
end