%CS 596, machine learning

%% step 1  load data 
load('crab.mat', 'X','Y');

n=200;
%split data 
S=randperm(n);
%100 training samples
Xtr=X(:,S(1:100));
Ytr=Y(:,S(1:100));
% 100 testing samples
Xte=X(:,S(101:end));
Yte=Y(:,S(101:end));

%% step 2 further split Xtr/Ytr into two even subsets: use one for training, another for validation.


%% step 3 Model selection over validation set
% consider the parameters C, kernel types (linear, RBF etc.) and kernal
% parameters if applicable. 

% 3.1 Plot the validation errors while using different values of C ( with other hyperparameters fixed); 


% 3.2 Plot the validation errors while using linear, RBF kernel, or Polynomial kernel ( with other hyperparameters fixed); 



%% step 4 Select the best model and apply it over the testing subset 


%% step 5 evaluate your results with the metrics you have developed in HA3,including accuracy, quantatize your resutls. 

 










