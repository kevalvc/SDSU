# This script is used to randomly generate a set of data points, and apply the adaboost method to classify these data points.

# from numpy import *
# import data
# import adaboost

import numpy as py


# Read data from Training or Testing file
def func_readData(filename, option):
    if option == 'train':
        fid = open(filename, 'r')

        label = []
        data = None
        while True:
            fline = fid.readline()
            if len(fline) == 0:  # EOF
                break
            label.append(int(fline[0:fline.find(':')]))

            dataNew = []
            i = fline.find(':') + 1
            dataNew = [float(fline[i:fline.find(',', i, -1)])]
            while True:
                i = fline.find(',', i, -1) + 1
                if not i:
                    break;
                dataNew.append(float(fline[i:fline.find(',', i, -1)]))
            if data is None:
                data = py.mat(dataNew)
            else:
                data = py.vstack([data, py.mat(dataNew)])
        fid.close()
        return data, label
    elif option == 'test':
        fid = open(filename, 'r')
        data = None
        while True:
            fline = fid.readline()
            if len(fline) == 0:  # EOF
                break
            dataNew = []
            i = 0
            while True:
                dataNew.append(float(fline[i:fline.find(',', i, -1)]))
                i = fline.find(',', i, -1) + 1
                if not i:
                    break
            if data is None:
                data = py.mat(dataNew)
            else:
                data = py.vstack([data, py.mat(dataNew)])
        fid.close()
        return data
    else:
        print('Wrong input parameter!')


# function for building weak classifiers, i.e.:  stump function

def buildWeakStump(d, l, D):  # (data, label, weight)
    dataMatrix = py.mat(d)
    labelmatrix = py.mat(l).T
    m, n = py.shape(dataMatrix)
    numstep = 10.0
    bestStump = {}
    bestClass = py.mat(py.zeros((5, 1)))
    minErr = py.inf
    for i in range(n):
        datamin = dataMatrix[:, i].min()
        datamax = dataMatrix[:, i].max()
        stepSize = (datamax - datamin) / numstep
        for j in range(-1, int(numstep) + 1):
            for inequal in ['lt', 'gt']:
                threshold = datamin + float(j) * stepSize
                predict = stumpClassify(dataMatrix, i, threshold, inequal)
                err = py.mat(py.ones((m, 1)))
                err[predict == labelmatrix] = 0
                weighted_err = D.T * err;
                if weighted_err < minErr:
                    minErr = weighted_err
                    bestClass = predict.copy()
                    bestStump['dim'] = i
                    bestStump['threshold'] = threshold
                    bestStump['ineq'] = inequal
    return bestStump, minErr, bestClass


# Use a weak classifier, i.e. a decision stump, to classify data

def stumpClassify(datamat, i, threshold, inequal):
    res = py.ones((py.shape(datamat)[0], 1))
    if inequal == 'lt':
        res[datamat[:, i] <= threshold] = -1.0
    else:
        res[datamat[:, i] > threshold] = -1.0
    return res


# Boosting Algorithm

def train(data, label, numIt=1000):
    weakClassifiers = []
    # m is the number of samples
    m = py.shape(data)[0]
    # sample weights, 1/m at the beginning
    D = py.mat(py.ones((m, 1)) / m)

    estStrong = py.mat(py.zeros((m, 1)))
    for i in range(numIt):
        # bestStump: weak classifier; error: error rate
        bestStump, error, classEstimate = buildWeakStump(data, label, D)

        ##### PLACEHOLDER 1 START ###
        # calculate the weight of the selected decision stump based on its error rate
        esp = 1e-16
        alpha = float(.5 * py.log((1 - error) / (error - esp)))
        ##### PLACEHOLDER 1 End ###

        # add one more field to bestStump, i.e. classifier weight
        bestStump['alpha'] = alpha
        # add bestStump to the list of weak classifiers
        weakClassifiers.append(bestStump)

        ##### PLACEHOLDER 2 START ###
        # calculate sample weights (of all samples)
        # set sample weights
        D = py.exp(alpha * -1 * classEstimate)
        # normalize D
        D = D / D.sum()
        ##### PLACEHOLDER 2 End ###

        estStrong += classEstimate * alpha

        EnsembleErrors = py.multiply(py.sign(estStrong) != py.mat(label).T, \
                                     py.ones((m, 1)))  # Converte to float

        errorRate = EnsembleErrors.sum() / m

        print("current error:  ", errorRate)
        if errorRate == 0.0:
            break
    return weakClassifiers


# Applying an adaboost classifier for a single data sample

def adaboostClassify(dataTest, classifier):
    dataMatrix = py.mat(dataTest)
    m = py.shape(dataMatrix)[0]
    estStrong = py.mat(py.zeros((m, 1)))
    for i in range(len(classifier)):
        ##### PLACEHOLDER 3 START ###
        # call the function stumpClassify()
        dim = classifier[i]['dim'],
        threshold = classifier[i]['threshold'],
        inequal = classifier[i]['ineq']

        classEstimate = stumpClassify(dataMatrix, dim, threshold, inequal)
        # accumulate all predictions
        estStrong += classifier[i]['alpha'] * classEstimate
        ##### PLACEHOLDER 3 START ###
    return py.sign(estStrong)


# Applying an adaboost classifier for all testing samples
def test(dataSet, classifier):
    label = []
    for i in range(py.shape(dataSet)[0]):
        label.append(adaboostClassify(dataSet[i, :], classifier))
        # label = adaboostClassify(dataSet[i,:],classifier)
    return label


#############. main ##################
# The data files "train.txt" and "test.txt" are randomly generated by the function
# randomData() and are used to test your developed codes.

trainData, label = func_readData('train.txt', 'train')
testData = func_readData('test.txt', 'test')

# Training
classifier = train(trainData, label, 150)
print('Training Done\n')

# Testing
predicted_label = test(testData, classifier)
print('Testing Complete\n')

# Print Predicited labels
print('Labels Predicted')
print(predicted_label)


