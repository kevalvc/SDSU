import numpy as np
import download_data as dl
import matplotlib.pyplot as plt
import sklearn.svm as svm
from sklearn import metrics
from conf_matrix import func_confusion_matrix

## step 1: load data from csv file.
data = dl.download_data('crab.csv').values

n = 200
#split data
S = np.random.permutation(n)
#100 training samples
Xtr = data[S[:100], :6]
Ytr = data[S[:100], 6:]
# 100 testing samples
X_test = data[S[100:], :6]
Y_test = data[S[100:], 6:].ravel()

## step 2 randomly split Xtr/Ytr into two even subsets: use one for training, another for validation.
#############placeholder: training/validation #######################
n2 = len(Xtr)
S2 = np.random.permutation(n2)

# subsets for training models
x_train= data[S2[:50],:6]
y_train= data[S2[:50],6:]
# subsets for validation
x_validation= data[S2[50:100],:6]
y_validation= data[S2[50:100],6:]
#############placeholder #######################

## step 3 Model selection over validation set
# consider the parameters C, kernel types (linear, RBF etc.) and kernal
# parameters if applicable.


# 3.1 Plot the validation errors while using different values of C ( with other hyperparameters fixed)
#  keeping kernel = "linear"
#############placeholder: Figure 1#######################

c_range = [2 , 4 , 6,  8, 10, 12]
# c_range = [0.02 , 0.05 , 0.09,  0.50, 0.9, 1]
# c_range = [0.04 , 0.08 , 0.3,  0.6, 0.9, 1]
svm_c_error = []
svm_c_error_test = []
svm_c_error_train = []
for c_value in c_range:
    model = svm.SVC(kernel='linear', C=c_value)
    # model = svm.SVC(kernel='polynomial', C=c_value)
    # model = svm.SVC(kernel= 'rbf', C=c_value)

    model.fit(X=x_train, y=y_train)
    error = 1. - model.score(x_validation, y_validation)
    svm_c_error.append(error)
    #
    # error1 = 1. - model.score(X_test, Y_test)
    # svm_c_error_test.append(error1)
    #
    # error2 = 1. - model.score(x_train, y_train)
    # svm_c_error_train.append(error2)

plt.plot(c_range, svm_c_error)
# plt.plot(c_range, svm_c_error_test)
# plt.plot(c_range, svm_c_error_train)
plt.title('validation errors using different values C (SVM)')
plt.xlabel('c values')
plt.ylabel('error')
#plt.xticks(c_range)
plt.show()
#############placeholder #######################


# 3.2 Plot the validation errors while using linear, RBF kernel, or Polynomial kernel ( with other hyperparameters fixed)
#############placeholder: Figure 2#######################

kernel_types = ['linear', 'poly', 'rbf']
svm_kernel_error = []
c_range = [1,3,6]
for kernel_value in kernel_types:
    model = svm.SVC(kernel = kernel_value )
    model.fit(X=x_train,y=y_train)
    error = 1. - model.score(x_validation,y_validation)
    svm_kernel_error.append(error)
    # your own codes
plt.plot(kernel_types, svm_kernel_error)
plt.title('SVM by Kernels')
plt.xlabel('Kernel')
plt.ylabel('error')
plt.xticks(kernel_types)
plt.show()


## step 4 Select the best model and apply it over the testing subset
best_kernel = 'linear'
best_c = 0.4 # poly had many that were the "best"
model = svm.SVC(kernel=best_kernel, C=best_c)
model.fit(X=x_train, y=y_train)

# Best model
c_range = [0.02 , 0.07 , 0.4,  0.60, 0.80, 1]
svmc_error = []
for c_value in c_range:
    model = svm.SVC(kernel='linear', C=c_value)
    model.fit(X=x_train, y=y_train)
    error = 1. - model.score(X_test, Y_test)
    svmc_error.append(error)

plt.plot(c_range, svmc_error)
plt.title('Best Model')
plt.xlabel('c values')
plt.ylabel('error')
plt.show()

## step 5 evaluate your results with the metrics you have developed in HA3,including accuracy, quantize your results.


y_pred = model.predict(X_test)
conf_matrix, accuracy, recall_array, precision_array = func_confusion_matrix(Y_test, y_pred)

print("Confusion Matrix: ")
print(conf_matrix)
print("Average Accuracy: {}".format(accuracy))
print("Per-Class Precision: {}".format(precision_array))
print("Per-Class Recall: {}".format(recall_array))

print("Failure Cases where female was categorized as male or vice versa:")
count =0;
for x in range(0, 100):
    if y_pred[x] != Y_test[x]:
        count+=1;
        print(y_pred[x],Y_test[x]);
        if count == 5:
            break;


print("True Cases:where female was categorized as female and male as mail")
count1 =0;
for x in range(0, 100):
    if y_pred[x] == Y_test[x]:
        count1+=1;
        print(y_pred[x],Y_test[x]);
        if count1 == 6:
            break;
